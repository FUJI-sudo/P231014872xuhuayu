(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f297932b._.js",
  "static/chunks/app_portfolio_PortfolioList_tsx_43775a81._.js"
],
    source: "dynamic"
});
