'use client';

import Link from 'next/link';
import { Card, Typography, Tag, Empty } from '@arco-design/web-react';

type Assignment = {
  filename: string;
  name: string;
};

type PortfolioListProps = {
  assignments: Assignment[];
  error?: boolean;
};

export default function PortfolioList({ assignments, error }: PortfolioListProps) {
  if (error) {
    return (
      <div className="text-center p-8 bg-black/30 rounded-lg backdrop-blur-sm text-white">
        <Typography.Title heading={3} className="!text-white">练习清单</Typography.Title>
        <Typography.Paragraph className="!text-red-400">
          动感超人也救不了我，加载失败了...
        </Typography.Paragraph>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 md:p-8 bg-black/30 rounded-lg backdrop-blur-sm w-full max-w-5xl mx-auto">
      <Typography.Title heading={2} className="!text-white text-center mb-8">
          练习清单
        </Typography.Title>
        
        {assignments.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {assignments.map((assignment) => (
            <Link href={`/portfolio/${assignment.filename}`} key={assignment.filename} className="block">
              <Card
                className="group transition-all duration-300 transform hover:scale-105 bg-white/60 border border-white/50 hover:bg-white/80"
                hoverable
              >
                <div className="text-gray-800">
                  <Typography.Title heading={5} className="!text-black truncate">
                    {assignment.name}
                  </Typography.Title>
                  <Typography.Paragraph className="!text-gray-700 mt-2">
                    嘿嘿，不点一下看看吗？有惊喜哦！
                  </Typography.Paragraph>
                  <div className="mt-4">
                    <Tag color="arcoblue" bordered={false}>练习</Tag>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
        ) : (
        <div className="text-center py-10">
            <Empty description={<span className="text-white/80">哎呀，这里好像被风间整理得太干净了！</span>} />
        </div>
      )}
    </div>
  );
} 