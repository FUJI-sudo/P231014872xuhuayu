'use client';

import WakaTimeStats from './WakaTimeStats';

export default function Footer() {
  return (
    <footer className="relative z-20 mt-24 text-white/90 border-t-4 border-yellow-300 bg-black/25">
      <div className="container mx-auto px-6 py-10">
        <div className="flex flex-col md:flex-row justify-between items-center gap-10">
          
          {/* Left Side: Brand and Quote */}
          <div className="text-center md:text-left">
            <div className="text-4xl font-bold tracking-wider" style={{fontFamily: "'Noto Serif SC', serif"}}>小新</div>
            <p className="mt-3 text-lg text-white/80">
              每天都开开心心，才是最重要的事哦！
            </p>
            <div className="flex justify-center md:justify-start space-x-4 text-sm mt-4 text-yellow-300/80 font-semibold">
              <span>#调皮</span>
              <span>#好奇</span>
              <span>#动感超人</span>
            </div>
          </div>

          {/* Right Side: WakaTime Stats */}
          <div className="text-center md:text-right">
            <div className="text-sm uppercase text-white/60 tracking-wider">今日份的努力</div>
            <div className="text-3xl font-bold mt-1 text-yellow-300">
              <WakaTimeStats />
            </div>
          </div>

        </div>
        
        {/* Bottom: Copyright */}
        <div className="mt-10 pt-8 border-t border-white/10 text-center text-sm text-white/50">
          <p className="mb-1">&copy; {new Date().getFullYear()} 野原家. All rights reserved.</p>
          <p>嘿嘿，今天的我也很帅气！</p>
        </div>
      </div>
    </footer>
  );
} 