'use client';

import Link from 'next/link';
import { Button, Card, Typography, Divider } from '@arco-design/web-react';
import { IconBook, IconMessage } from '@arco-design/web-react/icon';

export default function Home() {
  const textShadow = { textShadow: '2px 2px 8px rgba(0, 0, 0, 0.6)' };

  return (
    <div className="flex flex-col justify-center items-center text-center text-white pt-16 px-4">
      {/* 主内容 */}
      <div className="w-full max-w-5xl">
        <h1 className="text-4xl sm:text-6xl font-bold mb-4" style={{ ...textShadow, fontFamily: "'Noto Serif SC', serif" }}>
          《web前端开发》课程练习
        </h1>
        
        <h2 className="text-2xl sm:text-3xl font-semibold mb-2" style={textShadow}>
          欢迎来到我的web世界
        </h2>
        
        <p className="text-lg sm:text-xl text-gray-200 mb-12" style={textShadow}>
          探索未知，拥抱无限可能
        </p>
        
        <div className="grid md:grid-cols-2 gap-8">
          {/* Card 1: Portfolio */}
          <Link href="/portfolio">
            <div className="group relative bg-black/30 p-8 rounded-2xl border border-white/20 backdrop-blur-md hover:border-yellow-300/50 transition-all duration-300 h-full flex flex-col items-center text-center">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity duration-300">
                    <IconBook style={{ fontSize: 80, color: 'white' }} />
                </div>
                <div className="relative w-full">
                    <Typography.Title heading={3} className="!text-white">
                        过往练习
                    </Typography.Title>
                    <Typography.Paragraph className="!text-gray-200 mt-3 min-h-[48px]">
                        这里面是写给娜娜子大姐姐的网页哦，不许偷看！
                    </Typography.Paragraph>
                    <Button type="primary" className="mt-6 !bg-yellow-400/80 hover:!bg-yellow-400 !text-black !font-bold">
                        查看杰作
                    </Button>
                </div>
            </div>
          </Link>
          
          {/* Card 2: AI Chat */}
          <Link href="/qanything">
             <div className="group relative bg-black/30 p-8 rounded-2xl border border-white/20 backdrop-blur-md hover:border-blue-400/50 transition-all duration-300 h-full flex flex-col items-center text-center">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity duration-300">
                    <IconMessage style={{ fontSize: 80, color: 'white' }} />
                </div>
                <div className="relative w-full">
                    <Typography.Title heading={3} className="!text-white">
                        AI 聊天
                    </Typography.Title>
                    <Typography.Paragraph className="!text-gray-200 mt-3 min-h-[48px]">
                        想知道动感超人的秘密吗？悄悄问我…
                    </Typography.Paragraph>
                    <Button type="primary" className="mt-6 !bg-blue-500/80 hover:!bg-blue-500 !text-white !font-bold">
                        开始聊天
                    </Button>
                </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
